const RULE_ID_START = 1000;
const USER_RULE_ID_START = 200000;
const ALLOW_RULE_ID_START = 300000;
const STORAGE_KEY = "teddyclowers.settings";

const DEFAULT_SETTINGS = {
  enabled: true,
  pausedSites: [],
  allowlist: [],
  userBlocklist: [],
  filterLists: ["TeddyClowers Starter Rules"],
};

function apiCall(method, ...args) {
  return new Promise((resolve, reject) => {
    chrome[method](...args, (result) => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else resolve(result);
    });
  });
}

async function getSettings() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return { ...DEFAULT_SETTINGS, ...(stored[STORAGE_KEY] || {}) };
}

async function saveSettings(settings) {
  await chrome.storage.local.set({ [STORAGE_KEY]: settings });
}

function hostFromUrl(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return "";
  }
}

function domainMatches(host, candidate) {
  const normalized = String(candidate || "").toLowerCase().replace(/^\*\./, "");
  return host === normalized || host.endsWith(`.${normalized}`);
}

function siteMatches(host, domains) {
  return domains.some((domain) => domainMatches(host, domain));
}

async function readGeneratedRules() {
  const response = await fetch(chrome.runtime.getURL("rules.json"));
  if (!response.ok) throw new Error(`Unable to load rules.json: ${response.status}`);
  return response.json();
}

function buildUserRules(settings) {
  const rules = [];
  settings.userBlocklist.forEach((domain, index) => {
    const normalized = String(domain).toLowerCase().replace(/^\*\./, "").trim();
    if (!normalized) return;
    rules.push({
      id: USER_RULE_ID_START + index,
      priority: 500,
      action: { type: "block" },
      condition: { requestDomains: [normalized] },
    });
  });
  return rules;
}

function buildAllowRules(settings) {
  const rules = [];
  if (!settings.enabled) {
    rules.push({
      id: ALLOW_RULE_ID_START,
      priority: 30000,
      action: { type: "allowAllRequests" },
      condition: { resourceTypes: ["main_frame", "sub_frame", "script", "image", "stylesheet", "xmlhttprequest", "media", "font", "object", "websocket", "other"] },
    });
  }
  settings.allowlist.forEach((domain, index) => {
    const normalized = String(domain).toLowerCase().replace(/^\*\./, "").trim();
    if (!normalized) return;
    rules.push({
      id: ALLOW_RULE_ID_START + 1000 + index,
      priority: 20000,
      action: { type: "allowAllRequests" },
      condition: { initiatorDomains: [normalized] },
    });
  });
  settings.pausedSites.forEach((domain, index) => {
    const normalized = String(domain).toLowerCase().replace(/^\*\./, "").trim();
    if (!normalized) return;
    rules.push({
      id: ALLOW_RULE_ID_START + 2000 + index,
      priority: 20000,
      action: { type: "allowAllRequests" },
      condition: { initiatorDomains: [normalized] },
    });
  });
  return rules;
}

async function rebuildRules() {
  const settings = await getSettings();
  const packaged = await readGeneratedRules();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((rule) => rule.id);
  const addRules = [...buildUserRules(settings), ...buildAllowRules(settings)];
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  return { settings, ruleCount: packaged.length + addRules.length };
}

async function activeTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

async function status() {
  const settings = await getSettings();
  const tab = await activeTab();
  const host = hostFromUrl(tab?.url || "");
  const paused = siteMatches(host, settings.pausedSites);
  const allowlisted = siteMatches(host, settings.allowlist);
  const rules = await chrome.declarativeNetRequest.getDynamicRules();
  const packaged = await readGeneratedRules();
  return {
    enabled: settings.enabled,
    host,
    paused,
    allowlisted,
    ruleCount: packaged.length + rules.length,
    filterLists: settings.filterLists,
    storeSafeMode: true,
    blockedCount: null,
  };
}

async function setDomain(listKey, domain, enabled) {
  const settings = await getSettings();
  const normalized = hostFromUrl(domain) || String(domain).toLowerCase().replace(/^\*\./, "").trim();
  if (!normalized) return status();
  const current = new Set(settings[listKey]);
  if (enabled) current.add(normalized);
  else current.delete(normalized);
  settings[listKey] = [...current].sort();
  await saveSettings(settings);
  await rebuildRules();
  return status();
}

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  if (!stored[STORAGE_KEY]) await saveSettings(DEFAULT_SETTINGS);
  await rebuildRules();
});

chrome.runtime.onStartup.addListener(() => rebuildRules());

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (message.type === "GET_STATUS") return status();
    if (message.type === "SET_ENABLED") {
      const settings = await getSettings();
      settings.enabled = Boolean(message.enabled);
      await saveSettings(settings);
      await rebuildRules();
      return status();
    }
    if (message.type === "SET_SITE_PAUSED") return setDomain("pausedSites", message.host, Boolean(message.paused));
    if (message.type === "SET_ALLOWLISTED") return setDomain("allowlist", message.host, Boolean(message.allowlisted));
    if (message.type === "ADD_BLOCKED_DOMAIN") return setDomain("userBlocklist", message.domain, true);
    if (message.type === "REMOVE_BLOCKED_DOMAIN") return setDomain("userBlocklist", message.domain, false);
    if (message.type === "REBUILD_RULES") {
      await rebuildRules();
      return status();
    }
    throw new Error(`Unknown TeddyClowers message: ${message.type}`);
  })().then(sendResponse).catch((error) => sendResponse({ error: error.message }));
  return true;
});
