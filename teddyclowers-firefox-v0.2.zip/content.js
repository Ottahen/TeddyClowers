const MAX_SELECTORS = 5000;
const MAX_MATCHED_NODES = 10000;

function currentHost() {
  return window.location.hostname.toLowerCase();
}

function domainMatches(host, candidate) {
  const normalized = String(candidate || "").toLowerCase().replace(/^\*\./, "");
  return host === normalized || host.endsWith(`.${normalized}`);
}

function applies(rule, host) {
  const included = !rule.domains?.length || rule.domains.some((domain) => domainMatches(host, domain));
  const excluded = rule.excluded_domains?.some((domain) => domainMatches(host, domain));
  return included && !excluded && !rule.exception && !rule.scriptlet;
}

async function loadRules() {
  const response = await fetch(chrome.runtime.getURL("cosmetic-rules.json"));
  if (!response.ok) return [];
  const rules = await response.json();
  return rules.filter((rule) => applies(rule, currentHost())).slice(0, MAX_SELECTORS);
}

function applyRules(rules) {
  let matched = 0;
  for (const rule of rules) {
    try {
      for (const node of document.querySelectorAll(rule.selector)) {
        if (matched >= MAX_MATCHED_NODES) return;
        node.setAttribute("data-teddyclowers-hidden", "true");
        matched += 1;
      }
    } catch {
      // Invalid selectors are ignored safely; the network engine is unaffected.
    }
  }
}

(async () => {
  const rules = await loadRules();
  if (!rules.length) return;
  const style = document.createElement("style");
  style.textContent = "[data-teddyclowers-hidden=\\\"true\\\"]{display:none!important;visibility:hidden!important}";
  document.documentElement.append(style);
  applyRules(rules);
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    queueMicrotask(() => { scheduled = false; applyRules(rules); });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
