const STORAGE_KEY = "teddyclowers.settings";
const DEFAULT_SETTINGS = { enabled: true, pausedSites: [], allowlist: [], userBlocklist: [], filterLists: ["TeddyClowers Starter Rules"] };
const $ = (selector) => document.querySelector(selector);

async function getSettings() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return { ...DEFAULT_SETTINGS, ...(stored[STORAGE_KEY] || {}) };
}

async function save(settings) {
  await chrome.storage.local.set({ [STORAGE_KEY]: settings });
  await chrome.runtime.sendMessage({ type: "REBUILD_RULES" });
}

function renderList(element, values, remove) {
  element.replaceChildren(...values.map((value) => {
    const item = document.createElement("li");
    const label = document.createElement("span");
    label.textContent = value;
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Remove";
    button.addEventListener("click", () => remove(value));
    item.append(label, button);
    return item;
  }));
}

async function render() {
  const settings = await getSettings();
  $("#enabled").checked = settings.enabled;
  renderList($("#allow-list"), settings.allowlist, async (value) => {
    settings.allowlist = settings.allowlist.filter((item) => item !== value);
    await save(settings); render();
  });
  renderList($("#block-list"), settings.userBlocklist, async (value) => {
    settings.userBlocklist = settings.userBlocklist.filter((item) => item !== value);
    await save(settings); render();
  });
}

async function addFrom(inputId, key) {
  const input = $(inputId);
  const value = input.value.trim().toLowerCase().replace(/^https?:\/\//, "").split("/")[0];
  if (!value || value.includes(" ")) return;
  const settings = await getSettings();
  settings[key] = [...new Set([...settings[key], value])].sort();
  await save(settings);
  input.value = "";
  await render();
}

$("#enabled").addEventListener("change", async (event) => {
  const settings = await getSettings();
  settings.enabled = event.target.checked;
  await save(settings);
});
$("#allow-add").addEventListener("click", () => addFrom("#allow-input", "allowlist"));
$("#block-add").addEventListener("click", () => addFrom("#block-input", "userBlocklist"));
$("#refresh").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "REBUILD_RULES" });
  $("#result").textContent = "Packaged rules reloaded locally.";
});
render();
