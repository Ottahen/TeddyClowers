const send = (message) => chrome.runtime.sendMessage(message);
const $ = (selector) => document.querySelector(selector);
let current;

function render(status) {
  current = status;
  $("#host").textContent = status.host || "This page";
  $("#rules").textContent = status.ruleCount ?? "—";
  $("#status").textContent = status.allowlisted ? "Trusted site — filtering bypassed" : status.paused ? "Protection is paused for this site" : status.enabled ? "Protected by TeddyClowers" : "Protection is off globally";
  const enabled = $("#enabled");
  enabled.classList.toggle("off", !status.enabled);
  $("#enabled-label").textContent = status.enabled ? "Protection active" : "Protection disabled";
  $("#pause").textContent = status.paused ? "Resume on this site" : "Pause on this site";
  $("#allow").textContent = status.allowlisted ? "Remove site trust" : "Trust this site";
}

async function refresh() {
  const status = await send({ type: "GET_STATUS" });
  if (status?.error) return;
  render(status);
}

$("#enabled").addEventListener("click", async () => {
  const status = await send({ type: "SET_ENABLED", enabled: !current.enabled });
  render(status);
});

$("#pause").addEventListener("click", async () => {
  const status = await send({ type: "SET_SITE_PAUSED", host: current.host, paused: !current.paused });
  render(status);
});

$("#allow").addEventListener("click", async () => {
  const status = await send({ type: "SET_ALLOWLISTED", host: current.host, allowlisted: !current.allowlisted });
  render(status);
});

$("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
refresh();
